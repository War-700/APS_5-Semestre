﻿namespace INTERFACE_REDES_APS
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelLogin = new Label();
            login = new TextBox();
            labelSenha = new Label();
            senha = new TextBox();
            entrar = new Button();
            SuspendLayout();
            // 
            // labelLogin
            // 
            labelLogin.Anchor = AnchorStyles.None;
            labelLogin.AutoSize = true;
            labelLogin.BackColor = Color.Transparent;
            labelLogin.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            labelLogin.Location = new Point(168, 119);
            labelLogin.Margin = new Padding(0);
            labelLogin.Name = "labelLogin";
            labelLogin.Padding = new Padding(2, 0, 2, 0);
            labelLogin.Size = new Size(83, 30);
            labelLogin.TabIndex = 0;
            labelLogin.Text = "LOGIN:";
            labelLogin.Click += label1_Click;
            // 
            // login
            // 
            login.Anchor = AnchorStyles.None;
            login.BorderStyle = BorderStyle.FixedSingle;
            login.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            login.Location = new Point(168, 152);
            login.MaxLength = 255;
            login.Multiline = true;
            login.Name = "login";
            login.RightToLeft = RightToLeft.No;
            login.Size = new Size(469, 34);
            login.TabIndex = 0;
            // 
            // labelSenha
            // 
            labelSenha.Anchor = AnchorStyles.None;
            labelSenha.AutoSize = true;
            labelSenha.BackColor = Color.Transparent;
            labelSenha.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            labelSenha.Location = new Point(168, 209);
            labelSenha.Margin = new Padding(0);
            labelSenha.Name = "labelSenha";
            labelSenha.Padding = new Padding(2, 0, 0, 0);
            labelSenha.Size = new Size(87, 30);
            labelSenha.TabIndex = 2;
            labelSenha.Text = "SENHA:";
            // 
            // senha
            // 
            senha.Anchor = AnchorStyles.None;
            senha.BorderStyle = BorderStyle.FixedSingle;
            senha.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            senha.Location = new Point(168, 242);
            senha.MaxLength = 255;
            senha.Multiline = true;
            senha.Name = "senha";
            senha.RightToLeft = RightToLeft.No;
            senha.Size = new Size(469, 34);
            senha.TabIndex = 3;
            // 
            // entrar
            // 
            entrar.Anchor = AnchorStyles.None;
            entrar.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            entrar.ForeColor = Color.Coral;
            entrar.Location = new Point(337, 342);
            entrar.Name = "entrar";
            entrar.Size = new Size(112, 36);
            entrar.TabIndex = 4;
            entrar.Text = "ENTRAR";
            entrar.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.branco_laranja;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(entrar);
            Controls.Add(labelSenha);
            Controls.Add(labelLogin);
            Controls.Add(senha);
            Controls.Add(login);
            Name = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelLogin;
        private TextBox login;
        private Label labelSenha;
        private TextBox senha;
        private Button entrar;
    }
}